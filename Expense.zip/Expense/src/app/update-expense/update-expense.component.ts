import { Component, OnInit } from '@angular/core';
import { Expense } from '../model/expense';
import { Router } from '@angular/router';
import { ExpenseService } from '../service/expense.service';

@Component({
  selector: 'app-update-expense',
  templateUrl: './update-expense.component.html',
  styleUrls: ['./update-expense.component.css']
})
export class UpdateExpenseComponent implements OnInit {

  exp: Expense = { expenseCode: 0, expenseType: '', expenseDescription: '' };
  expenses: Expense[];
  // tslint:disable-next-line: no-shadowed-variable
  constructor(private ExpenseService: ExpenseService, private router: Router) { }

  ngOnInit() {
  
  }
  update() {
    
    this.ExpenseService.updateExpense(this.exp.expenseCode).subscribe((data) => this.exp = data,
      (error) => {
        console.error(error);
      }
    );
    this.expenses = this.ExpenseService.getAllExpenses();
    this.ExpenseService.setExpenses(this.expenses);
    this.router.navigate(['displayall']);

  }


 

}
