import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Expense } from '../model/expense';
import { throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class ExpenseService {
  expenses: Expense[];
  expenses1: Expense;
  status: string;
  filteredData: Expense[];
  index: number;
  expense: Expense;
  constructor(private http: HttpClient) {
    this.getExpenses();
  }
  getData(): Observable<Expense[]> {
    return this.http.get<Expense[]>('http://localhost:1111/ExpenseCode/displayall/');

  }
  getExpenses() {
    this.getData().subscribe((data: Expense[]) => {
      this.expenses = data;
      console.log(this.expenses);


    });
  }
  handlError(error) {
    console.log(error);
    return throwError;
  }
  getAllExpenses() {
    return this.expenses;
  }
  setExpenses(expen) {
    this.expenses.push(expen);
  }
  getAddExpenses() {
    return this.expenses;
  }
  addExpense(exp: Expense):Observable<any> {
    
    return this.http.post('http://localhost:1111/ExpenseCode/add/', exp);  
  }
  getSearchedData() {
    return this.filteredData;
  }
  deleteExpense(i: number) {
    return this.http.delete('http://localhost:1111/ExpenseCode/delete/' + i, { responseType: 'text' });
  }
  setIndex(i) {
    this.index = i;
  }
  getIndex() {
    return this.index;
  }
  getExpense(i) {
    return this.expenses[i];
  }
  updateExpense(i: number): Observable<any>
   {
     return this.http.post('http://localhost:1111/ExpenseCode/update/' + i, { responseType: 'text' });  
  }
}
